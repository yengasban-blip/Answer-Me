import { useEffect, useState } from 'react';

interface Raindrop {
  id: number;
  left: number;
  height: number;
  duration: number;
  delay: number;
  opacity: number;
}

export function SadRainEffect() {
  const [drops, setDrops] = useState<Raindrop[]>([]);

  useEffect(() => {
    const list: Raindrop[] = Array.from({ length: 35 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      height: Math.floor(Math.random() * 18) + 12,
      duration: Math.random() * 1.5 + 1.2,
      delay: Math.random() * 3,
      opacity: Math.random() * 0.4 + 0.2,
    }));
    setDrops(list);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {drops.map((drop) => (
        <span
          key={drop.id}
          className="absolute bg-slate-400/40 w-[1.5px] rounded-full animate-rain"
          style={{
            left: `${drop.left}%`,
            top: '-25px',
            height: `${drop.height}px`,
            opacity: drop.opacity,
            animationDuration: `${drop.duration}s`,
            animationDelay: `${drop.delay}s`,
          }}
          aria-hidden="true"
        />
      ))}
    </div>
  );
}
