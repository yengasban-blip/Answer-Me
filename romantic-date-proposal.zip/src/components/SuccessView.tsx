import { useEffect, useState } from 'react';
import {
  Heart,
  Plane,
  CheckCircle2,
  Copy,
  Mail,
  Calendar,
  Clock,
  MapPin,
  Utensils,
  Sparkles,
  ArrowLeft,
  Coffee,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { DatePlanPayload, formatPlanSummary, generateMailtoUrl } from '../services/emailService';
import { RECIPIENT_EMAIL } from '../data/dateOptions';

interface SuccessViewProps {
  data: DatePlanPayload;
  onEdit: () => void;
  onReset: () => void;
}

export function SuccessView({ data, onEdit, onReset }: SuccessViewProps) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 },
        colors: ['#e11d48', '#f43f5e', '#fb7185', '#fda4af', '#fecdd3'],
      });
    } catch {
      // ignore
    }
  }, []);

  const handleCopy = () => {
    const text = formatPlanSummary(data);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const mailtoUrl = generateMailtoUrl(data);

  return (
    <div className="relative z-10 w-full max-w-xl mx-auto p-4 transition-all duration-300">
      
      {/* Celebration Header */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-rose-500 text-white shadow-xl shadow-rose-300/50 mb-3 animate-bounce">
          <Heart className="w-8 h-8 fill-white" />
        </div>
        <h2 className="font-script text-5xl sm:text-6xl text-rose-500 leading-none">
          It&apos;s a Date! ♥
        </h2>
        <p className="text-sm text-rose-900/80 mt-1">
          Thank you for saying yes! Looking forward to spending time before your flight. ✈️✨
        </p>
      </div>

      {/* Romantic Date Boarding Pass Card */}
      <div className="bg-white rounded-3xl shadow-2xl shadow-rose-200/60 border border-rose-100 overflow-hidden text-rose-950">
        
        {/* Pass Header */}
        <div className="bg-gradient-to-r from-rose-500 to-pink-500 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Plane className="w-6 h-6 -rotate-45" />
            <div>
              <div className="text-[10px] uppercase tracking-widest font-semibold opacity-90">
                Official Romantic Boarding Pass
              </div>
              <div className="font-bold text-lg leading-tight">Pre-Flight Date Ticket</div>
            </div>
          </div>
          <div className="text-right">
            <span className="bg-white/20 text-white text-xs px-2.5 py-1 rounded-full font-medium">
              Confirmed ♥
            </span>
          </div>
        </div>

        {/* Pass Details */}
        <div className="p-6 space-y-5">
          {/* Top Info Grid */}
          <div className="grid grid-cols-2 gap-4 pb-4 border-b border-rose-100">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-rose-400 font-semibold block mb-0.5">
                Preferred Date
              </span>
              <div className="flex items-center gap-1.5 font-bold text-sm text-rose-900">
                <Calendar className="w-3.5 h-3.5 text-rose-500" />
                <span>{data.selectedDate || 'Any Weekday'}</span>
              </div>
            </div>

            <div>
              <span className="text-[11px] uppercase tracking-wider text-rose-400 font-semibold block mb-0.5">
                Preferred Time
              </span>
              <div className="flex items-center gap-1.5 font-bold text-sm text-rose-900">
                <Clock className="w-3.5 h-3.5 text-rose-500" />
                <span>{data.preferredTime || 'Flexible'}</span>
              </div>
            </div>
          </div>

          {/* Activities & Selected Spots */}
          <div className="space-y-2">
            <span className="text-[11px] uppercase tracking-wider text-rose-400 font-semibold block">
              Chosen Activities & Venues
            </span>
            <div className="flex flex-wrap gap-2">
              {(data.activityType || []).map((act) => (
                <span
                  key={act}
                  className="bg-rose-50 border border-rose-200 text-rose-800 text-xs px-3 py-1 rounded-xl font-medium"
                >
                  {act}
                </span>
              ))}
            </div>

            {/* Cafe */}
            {(data.cafeChoice || data.customCafe) && (
              <div className="flex items-center gap-2 text-xs text-rose-900 bg-rose-50/60 p-2.5 rounded-xl border border-rose-100">
                <Coffee className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="font-medium">Cafe:</span>
                <span className="font-bold">{data.customCafe || data.cafeChoice}</span>
              </div>
            )}

            {/* Mall */}
            {(data.mallChoice || data.customMall) && (
              <div className="flex items-center gap-2 text-xs text-rose-900 bg-rose-50/60 p-2.5 rounded-xl border border-rose-100">
                <MapPin className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="font-medium">Mall:</span>
                <span className="font-bold">{data.customMall || data.mallChoice}</span>
              </div>
            )}

            {/* Staycation */}
            {(data.staycationChoice || data.customStaycation) && (
              <div className="flex items-center gap-2 text-xs text-rose-900 bg-rose-50/60 p-2.5 rounded-xl border border-rose-100">
                <MapPin className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="font-medium">Staycation:</span>
                <span className="font-bold">{data.customStaycation || data.staycationChoice}</span>
              </div>
            )}
          </div>

          {/* Suggestion Fields Section */}
          {(data.planWhere || data.planExpectation || data.planWhatToEat || data.planActivities) && (
            <div className="bg-rose-50/80 rounded-2xl p-4 border border-rose-100 space-y-2 text-xs">
              <span className="font-bold text-rose-900 flex items-center gap-1.5 mb-1 text-xs">
                <Sparkles className="w-3.5 h-3.5 text-rose-500" />
                Your Custom Plans & Suggestions:
              </span>
              {data.planWhere && (
                <div className="flex items-start gap-1">
                  <span className="font-semibold text-rose-700 min-w-16">Where:</span>
                  <span className="text-rose-900">{data.planWhere}</span>
                </div>
              )}
              {data.planExpectation && (
                <div className="flex items-start gap-1">
                  <span className="font-semibold text-rose-700 min-w-16">Expect:</span>
                  <span className="text-rose-900">{data.planExpectation}</span>
                </div>
              )}
              {data.planWhatToEat && (
                <div className="flex items-start gap-1">
                  <span className="font-semibold text-rose-700 min-w-16">To Eat:</span>
                  <span className="text-rose-900">{data.planWhatToEat}</span>
                </div>
              )}
              {data.planActivities && (
                <div className="flex items-start gap-1">
                  <span className="font-semibold text-rose-700 min-w-16">Activities:</span>
                  <span className="text-rose-900">{data.planActivities}</span>
                </div>
              )}
            </div>
          )}

          {/* Personal Note */}
          {data.personalNote && (
            <div className="p-3 bg-pink-50/60 rounded-xl border border-pink-100 text-xs italic text-rose-800">
              &quot;{data.personalNote}&quot;
            </div>
          )}

          {/* Delivery Status */}
          <div className="pt-2 border-t border-rose-100 flex items-center justify-between text-xs text-rose-700">
            <span className="flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              Response sent to:
            </span>
            <span className="font-mono font-semibold text-rose-900 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
              {RECIPIENT_EMAIL}
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="bg-rose-50/70 p-4 border-t border-rose-100 flex flex-col sm:flex-row gap-2.5">
          <button
            onClick={handleCopy}
            className="flex-1 py-2.5 px-4 bg-white hover:bg-rose-50 text-rose-800 border border-rose-200 rounded-xl text-xs font-semibold shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Copy className="w-4 h-4 text-rose-500" />
            <span>{copied ? 'Copied to Clipboard! ✓' : 'Copy Plan for Chat'}</span>
          </button>

          <a
            href={mailtoUrl}
            className="flex-1 py-2.5 px-4 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold shadow-md shadow-rose-300/40 transition-all flex items-center justify-center gap-2 cursor-pointer text-center"
          >
            <Mail className="w-4 h-4 fill-white" />
            <span>Open in Mail App</span>
          </a>
        </div>
      </div>

      {/* Footer navigation */}
      <div className="mt-4 flex items-center justify-center gap-4 text-xs text-rose-500">
        <button
          onClick={onEdit}
          className="hover:underline cursor-pointer flex items-center gap-1"
        >
          <ArrowLeft className="w-3 h-3" />
          <span>Edit choices</span>
        </button>
        <span>·</span>
        <button
          onClick={onReset}
          className="hover:underline cursor-pointer"
        >
          Start over
        </button>
      </div>
    </div>
  );
}
