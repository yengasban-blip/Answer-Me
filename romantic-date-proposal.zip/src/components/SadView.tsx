import React, { useState } from 'react';
import { CloudRain, Send, ArrowLeft, Sparkles, CheckCircle2 } from 'lucide-react';
import sadTeddyImg from '../assets/images/sad_heartbreak_teddy_1791798881561.jpg';
import { SAD_REASON_SUGGESTIONS, RECIPIENT_EMAIL } from '../data/dateOptions';
import { sendDateResponseEmail, generateMailtoUrl } from '../services/emailService';
import { SadRainEffect } from './SadRainEffect';

interface SadViewProps {
  onBack: () => void;
  onChangedMind: () => void;
}

export function SadView({ onBack, onChangedMind }: SadViewProps) {
  const [reason, setReason] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSelectTag = (tag: string) => {
    setSelectedTag(tag);
    if (!reason.includes(tag)) {
      setReason((prev) => (prev ? `${prev}\n• ${tag}` : tag));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;

    setIsSubmitting(true);
    await sendDateResponseEmail({
      responseType: 'no',
      noReason: reason,
      submittedAt: new Date().toLocaleString(),
    });
    setIsSubmitting(false);
    setSubmitted(true);
  };

  const mailtoUrl = generateMailtoUrl({
    responseType: 'no',
    noReason: reason,
    submittedAt: new Date().toLocaleString(),
  });

  return (
    <div className="relative min-h-[85vh] flex items-center justify-center p-4">
      {/* Background Sad Rain Effect */}
      <SadRainEffect />

      <div className="relative z-10 w-full max-w-lg mx-auto bg-slate-900/90 backdrop-blur-md rounded-3xl shadow-2xl shadow-slate-950/40 border border-slate-700/60 p-6 sm:p-9 text-slate-100 transition-all duration-300">
        
        {/* Melancholic Image Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden shadow-lg border-2 border-slate-700 mb-4 bg-slate-800">
            <img
              src={sadTeddyImg}
              alt="Sad teddy bear in the rain holding a mended heart"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover grayscale-[25%]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />
            <div className="absolute bottom-1 right-1 text-slate-400 bg-slate-900/80 rounded-full p-1">
              <CloudRain className="w-3.5 h-3.5" />
            </div>
          </div>

          <h2 className="font-script text-4xl sm:text-5xl text-rose-300/90 leading-tight">
            It&apos;s okay <span className="text-rose-400">♥</span>
          </h2>

          <p className="text-slate-300 text-sm mt-1 max-w-xs leading-relaxed">
            I understand how stressful pre-flight preparation can get. Can you tell me why?
          </p>
        </div>

        {submitted ? (
          <div className="bg-slate-800/80 border border-slate-700 rounded-2xl p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-slate-700 flex items-center justify-center mx-auto text-rose-300">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <div>
              <h3 className="font-semibold text-lg text-white">Thank you for sharing with me</h3>
              <p className="text-xs text-slate-300 mt-1">
                Your thoughts have been sent to <span className="font-mono text-rose-300">{RECIPIENT_EMAIL}</span>. Have a safe, peaceful flight ahead! ✈️
              </p>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row gap-2">
              <a
                href={mailtoUrl}
                className="flex-1 py-2.5 px-4 bg-slate-700 hover:bg-slate-600 rounded-xl text-xs font-medium text-slate-200 transition-colors text-center"
              >
                Send via Email App
              </a>
              <button
                onClick={onChangedMind}
                className="flex-1 py-2.5 px-4 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold shadow-md transition-colors"
              >
                Wait, I want to go on a date! 💖
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Quick Reason Suggestions */}
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-2">
                Quick reasons (tap to add):
              </label>
              <div className="flex flex-wrap gap-2">
                {SAD_REASON_SUGGESTIONS.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleSelectTag(tag)}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition-all text-left cursor-pointer ${
                      selectedTag === tag || reason.includes(tag)
                        ? 'bg-rose-950/60 border-rose-500/50 text-rose-200 font-medium'
                        : 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:border-slate-600 hover:bg-slate-800'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Textarea for honest thoughts */}
            <div>
              <label htmlFor="reasonNo" className="block text-xs font-semibold text-rose-300 mb-1.5">
                Please share your thoughts:
              </label>
              <textarea
                id="reasonNo"
                name="reasonNo"
                rows={4}
                required
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Share your thoughts honestly... I appreciate your openness."
                className="w-full px-4 py-3 bg-slate-950/60 border border-slate-700 rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-rose-400 focus:ring-1 focus:ring-rose-400 transition-colors resize-none"
              />
            </div>

            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <span>Your message will be sent privately to</span>
              <span className="font-mono text-rose-300/90 underline decoration-dotted">{RECIPIENT_EMAIL}</span>
            </div>

            {/* Submit & Secondary Action Buttons */}
            <div className="space-y-3 pt-1">
              <button
                type="submit"
                disabled={isSubmitting || !reason.trim()}
                className="w-full py-3 px-5 bg-slate-700 hover:bg-slate-600 disabled:opacity-50 text-white rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                {isSubmitting ? (
                  <span>Sending gently...</span>
                ) : (
                  <>
                    <Send className="w-4 h-4 text-slate-300" />
                    <span>Send reason to Ellerellama02</span>
                  </>
                )}
              </button>

              {/* Sweet Reversal Button */}
              <button
                type="button"
                onClick={onChangedMind}
                className="w-full py-2.5 px-4 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-rose-300" />
                <span>Actually, I want to see you! Take me to date planning 💖</span>
              </button>

              <button
                type="button"
                onClick={onBack}
                className="w-full py-2 text-xs text-slate-400 hover:text-slate-200 transition-colors flex items-center justify-center gap-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to invitation</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
