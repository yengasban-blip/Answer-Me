import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Coffee,
  ShoppingBag,
  Home,
  Sparkles,
  Check,
  Heart,
  Send,
  ArrowLeft,
  MapPin,
  UtensilsCrossed,
  Smile,
  Compass,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  CAFE_OPTIONS,
  MALL_OPTIONS,
  STAYCATION_OPTIONS,
  TIME_OF_DAY_OPTIONS,
  RECIPIENT_EMAIL,
} from '../data/dateOptions';
import { DatePlanPayload, sendDateResponseEmail } from '../services/emailService';

interface YesPlanningViewProps {
  onBack: () => void;
  onSuccess: (data: DatePlanPayload) => void;
}

export function YesPlanningView({ onBack, onSuccess }: YesPlanningViewProps) {
  // Date & Time state
  const [selectedDate, setSelectedDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('Afternoon Chill & Snacks');

  // Activities state
  const [activeTab, setActiveTab] = useState<'cafe' | 'mall' | 'staycation' | 'custom'>('cafe');
  const [selectedActivities, setSelectedActivities] = useState<string[]>(['Cafe']);

  // Specific selections
  const [cafeChoice, setCafeChoice] = useState<string>('Akapela Cafe');
  const [customCafe, setCustomCafe] = useState('');

  const [mallChoice, setMallChoice] = useState<string>('Trinoma');
  const [customMall, setCustomMall] = useState('');

  const [staycationChoice, setStaycationChoice] = useState<string>('Morato Area');
  const [customStaycation, setCustomStaycation] = useState('');

  // Suggestion fields requested by user
  const [planWhere, setPlanWhere] = useState('');
  const [planExpectation, setPlanExpectation] = useState('');
  const [planWhatToEat, setPlanWhatToEat] = useState('');
  const [planActivities, setPlanActivities] = useState('');
  const [personalNote, setPersonalNote] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Helper to calculate upcoming weekdays
  const getUpcomingWeekdays = () => {
    const days: { label: string; dateStr: string; weekday: string }[] = [];
    const now = new Date();
    let current = new Date(now);

    while (days.length < 5) {
      current.setDate(current.getDate() + 1);
      const dayOfWeek = current.getDay();
      // 1 = Monday, 5 = Friday
      if (dayOfWeek >= 1 && dayOfWeek <= 5) {
        const weekday = current.toLocaleDateString('en-US', { weekday: 'short' });
        const monthDay = current.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        const dateStr = current.toISOString().split('T')[0];
        days.push({ label: `${weekday}, ${monthDay}`, dateStr, weekday });
      }
    }
    return days;
  };

  const upcomingWeekdays = getUpcomingWeekdays();

  const toggleActivity = (activity: string) => {
    setSelectedActivities((prev) =>
      prev.includes(activity) ? prev.filter((a) => a !== activity) : [...prev, activity]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const payload: DatePlanPayload = {
      responseType: 'yes',
      selectedDate: selectedDate || 'This upcoming weekday',
      preferredTime,
      activityType: selectedActivities.length > 0 ? selectedActivities : ['Cafe'],
      cafeChoice: selectedActivities.includes('Cafe') ? cafeChoice : undefined,
      customCafe: cafeChoice === 'Any on your mind?' ? customCafe : undefined,
      mallChoice: selectedActivities.includes('Mall') ? mallChoice : undefined,
      customMall: mallChoice === 'Any mall you desire to go' ? customMall : undefined,
      staycationChoice: selectedActivities.includes('Staycation') ? staycationChoice : undefined,
      customStaycation: staycationChoice === 'Other Staycation Spot' ? customStaycation : undefined,
      planWhere,
      planExpectation,
      planWhatToEat,
      planActivities,
      personalNote,
      submittedAt: new Date().toLocaleString(),
    };

    // Confetti explosion
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#f43f5e', '#fb7185', '#fda4af', '#fecdd3', '#ffd1dc'],
      });
    } catch {
      // Ignore if confetti context unavailable
    }

    await sendDateResponseEmail(payload);
    setIsSubmitting(false);
    onSuccess(payload);
  };

  return (
    <div className="relative z-10 w-full max-w-2xl mx-auto bg-white/95 backdrop-blur-md rounded-3xl shadow-2xl shadow-rose-200/50 border border-rose-100 p-6 sm:p-10 text-rose-950 transition-all duration-300">
      
      {/* Header */}
      <div className="text-center mb-8">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs text-rose-500 hover:text-rose-700 font-semibold mb-3 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to invitation</span>
        </button>
        <h2 className="font-script text-5xl sm:text-6xl text-rose-500 leading-none mb-1">
          Great! ♥
        </h2>
        <p className="text-sm sm:text-base text-rose-900/80 max-w-md mx-auto">
          Answer a few questions for us to plan the perfect date before your flight:
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        
        {/* SECTION 1: DATE PREFERENCE */}
        <div className="bg-rose-50/60 rounded-2xl p-5 border border-rose-100 space-y-4">
          <div className="flex items-center gap-2 text-rose-900 font-semibold text-sm sm:text-base">
            <Calendar className="w-4 h-4 text-rose-500" />
            <label htmlFor="datePreference">What date do you prefer?</label>
          </div>

          {/* Quick Weekday Buttons */}
          <div>
            <div className="text-xs font-medium text-rose-700/80 mb-2">
              Quick weekday options before your flight:
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {upcomingWeekdays.map((day) => (
                <button
                  key={day.dateStr}
                  type="button"
                  onClick={() => setSelectedDate(day.label)}
                  className={`px-2.5 py-2 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                    selectedDate === day.label
                      ? 'bg-rose-500 text-white border-rose-500 shadow-sm'
                      : 'bg-white text-rose-900 border-rose-200 hover:border-rose-300 hover:bg-rose-50'
                  }`}
                >
                  <div className="font-bold">{day.weekday}</div>
                  <div className="text-[10px] opacity-90">{day.label.split(', ')[1]}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Date Input */}
          <div className="flex items-center gap-2">
            <input
              type="date"
              id="datePreference"
              name="datePreference"
              value={selectedDate.startsWith('20') ? selectedDate : ''}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-white border border-rose-200 rounded-xl text-sm text-rose-950 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500"
            />
            {selectedDate && (
              <span className="text-xs text-rose-600 font-medium whitespace-nowrap bg-rose-100 px-2.5 py-1.5 rounded-lg">
                Selected: {selectedDate}
              </span>
            )}
          </div>

          {/* Time of Day Preference */}
          <div className="pt-2 border-t border-rose-100">
            <div className="flex items-center gap-2 text-xs font-medium text-rose-800 mb-2">
              <Clock className="w-3.5 h-3.5 text-rose-500" />
              <span>Preferred time of day:</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {TIME_OF_DAY_OPTIONS.map((time) => (
                <button
                  key={time.id}
                  type="button"
                  onClick={() => setPreferredTime(time.label)}
                  className={`p-2.5 rounded-xl text-xs border text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                    preferredTime === time.label
                      ? 'bg-rose-500 text-white border-rose-500 shadow-sm'
                      : 'bg-white text-rose-900 border-rose-200 hover:bg-rose-50'
                  }`}
                >
                  <span className="text-base">{time.icon}</span>
                  <div>
                    <div className="font-semibold">{time.label}</div>
                    <div className={`text-[10px] ${preferredTime === time.label ? 'text-rose-100' : 'text-rose-600'}`}>
                      {time.time}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* SECTION 2: ACTIVITY PREFERENCE & TABS */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <label className="text-rose-900 font-semibold text-sm sm:text-base flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-rose-500" />
              Choose an activity (or combine):
            </label>
            <span className="text-xs text-rose-500 font-medium">Select all you like</span>
          </div>

          {/* Activity Category Selection Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <button
              type="button"
              onClick={() => {
                toggleActivity('Cafe');
                setActiveTab('cafe');
              }}
              className={`p-3 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                selectedActivities.includes('Cafe')
                  ? 'bg-rose-500 text-white border-rose-500 shadow-md ring-2 ring-rose-200'
                  : 'bg-white text-rose-900 border-rose-200 hover:bg-rose-50'
              }`}
            >
              <Coffee className="w-5 h-5" />
              <span className="text-xs font-semibold">Cafe Date</span>
              <span className="text-[10px] opacity-80">Photo choices</span>
            </button>

            <button
              type="button"
              onClick={() => {
                toggleActivity('Mall');
                setActiveTab('mall');
              }}
              className={`p-3 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                selectedActivities.includes('Mall')
                  ? 'bg-rose-500 text-white border-rose-500 shadow-md ring-2 ring-rose-200'
                  : 'bg-white text-rose-900 border-rose-200 hover:bg-rose-50'
              }`}
            >
              <ShoppingBag className="w-5 h-5" />
              <span className="text-xs font-semibold">Mall Stroll</span>
              <span className="text-[10px] opacity-80">SM, Trinoma, MOA</span>
            </button>

            <button
              type="button"
              onClick={() => {
                toggleActivity('Staycation');
                setActiveTab('staycation');
              }}
              className={`p-3 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                selectedActivities.includes('Staycation')
                  ? 'bg-rose-500 text-white border-rose-500 shadow-md ring-2 ring-rose-200'
                  : 'bg-white text-rose-900 border-rose-200 hover:bg-rose-50'
              }`}
            >
              <Home className="w-5 h-5" />
              <span className="text-xs font-semibold">Staycation</span>
              <span className="text-[10px] opacity-80">Meal & rest together</span>
            </button>

            <button
              type="button"
              onClick={() => {
                toggleActivity('Custom Plan');
                setActiveTab('custom');
              }}
              className={`p-3 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center gap-1.5 ${
                selectedActivities.includes('Custom Plan')
                  ? 'bg-rose-500 text-white border-rose-500 shadow-md ring-2 ring-rose-200'
                  : 'bg-white text-rose-900 border-rose-200 hover:bg-rose-50'
              }`}
            >
              <Compass className="w-5 h-5" />
              <span className="text-xs font-semibold">Custom Idea</span>
              <span className="text-[10px] opacity-80">Indicate plans</span>
            </button>
          </div>

          {/* NAVIGATION TABS TO CONFIGURE SPECIFICS */}
          <div className="flex border-b border-rose-100 gap-2 pt-2">
            <button
              type="button"
              onClick={() => setActiveTab('cafe')}
              className={`pb-2 px-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'cafe'
                  ? 'border-rose-500 text-rose-600'
                  : 'border-transparent text-rose-400 hover:text-rose-600'
              }`}
            >
              1. Cafe Choices (Photos)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('mall')}
              className={`pb-2 px-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'mall'
                  ? 'border-rose-500 text-rose-600'
                  : 'border-transparent text-rose-400 hover:text-rose-600'
              }`}
            >
              2. Mall Choices
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('staycation')}
              className={`pb-2 px-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'staycation'
                  ? 'border-rose-500 text-rose-600'
                  : 'border-transparent text-rose-400 hover:text-rose-600'
              }`}
            >
              3. Staycation Areas
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('custom')}
              className={`pb-2 px-3 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                activeTab === 'custom'
                  ? 'border-rose-500 text-rose-600'
                  : 'border-transparent text-rose-400 hover:text-rose-600'
              }`}
            >
              4. Custom Plans
            </button>
          </div>

          {/* TAB 1: CAFE PHOTO SELECTION */}
          {activeTab === 'cafe' && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-rose-800">
                  Pick your favorite cafe spot:
                </span>
                <span className="text-[11px] text-rose-500 font-medium">
                  Selected: {cafeChoice === 'Any on your mind?' ? (customCafe || 'Custom Suggestion') : cafeChoice}
                </span>
              </div>

              {/* Cafe Grid with Photos */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {CAFE_OPTIONS.map((cafe) => {
                  const isSelected = cafeChoice === cafe.name;
                  return (
                    <div
                      key={cafe.id}
                      onClick={() => {
                        setCafeChoice(cafe.name);
                        if (!selectedActivities.includes('Cafe')) {
                          setSelectedActivities((prev) => [...prev, 'Cafe']);
                        }
                      }}
                      className={`group relative rounded-2xl overflow-hidden border-2 transition-all cursor-pointer bg-white text-left ${
                        isSelected
                          ? 'border-rose-500 shadow-md ring-2 ring-rose-200'
                          : 'border-rose-100 hover:border-rose-300 shadow-sm'
                      }`}
                    >
                      {cafe.image ? (
                        <div className="relative h-36 w-full overflow-hidden bg-rose-50">
                          <img
                            src={cafe.image}
                            alt={cafe.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                          
                          {/* Special Badge (e.g. Akapela first date) */}
                          {cafe.isSpecial && (
                            <span className="absolute top-2 left-2 bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-md flex items-center gap-1">
                              <Heart className="w-2.5 h-2.5 fill-white" />
                              {cafe.specialBadge}
                            </span>
                          )}

                          {isSelected && (
                            <span className="absolute top-2 right-2 bg-white text-rose-600 rounded-full p-1 shadow-md">
                              <Check className="w-3.5 h-3.5 stroke-[3]" />
                            </span>
                          )}

                          <div className="absolute bottom-2 left-3 right-3 text-white">
                            <h4 className="font-bold text-sm leading-tight text-white drop-shadow-sm">
                              {cafe.name}
                            </h4>
                          </div>
                        </div>
                      ) : (
                        <div className="h-36 w-full bg-gradient-to-br from-rose-100 to-pink-50 p-4 flex flex-col justify-between">
                          <div className="flex items-center justify-between">
                            <span className="text-2xl">✨</span>
                            {isSelected && (
                              <span className="bg-rose-500 text-white rounded-full p-1 shadow-md">
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </span>
                            )}
                          </div>
                          <div>
                            <h4 className="font-bold text-sm text-rose-950">
                              {cafe.name}
                            </h4>
                            <p className="text-[11px] text-rose-700/90 mt-0.5">
                              {cafe.description}
                            </p>
                          </div>
                        </div>
                      )}

                      <div className="p-3">
                        <p className="text-xs text-rose-800/80 leading-snug">
                          {cafe.description}
                        </p>
                        {cafe.isCustom && isSelected && (
                          <div className="mt-2.5">
                            <input
                              type="text"
                              value={customCafe}
                              onChange={(e) => setCustomCafe(e.target.value)}
                              placeholder="Type cafe name or location..."
                              className="w-full px-3 py-1.5 text-xs bg-rose-50 border border-rose-200 rounded-lg focus:outline-none focus:border-rose-500"
                              onClick={(e) => e.stopPropagation()}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: MALL CHOICES */}
          {activeTab === 'mall' && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-rose-800">
                  Select your desired mall:
                </span>
                <span className="text-[11px] text-rose-500 font-medium">
                  Selected: {mallChoice === 'Any mall you desire to go' ? (customMall || 'Custom Mall') : mallChoice}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {MALL_OPTIONS.map((mall) => {
                  const isSelected = mallChoice === mall.name;
                  return (
                    <button
                      key={mall.id}
                      type="button"
                      onClick={() => {
                        setMallChoice(mall.name);
                        if (!selectedActivities.includes('Mall')) {
                          setSelectedActivities((prev) => [...prev, 'Mall']);
                        }
                      }}
                      className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-rose-500 text-white border-rose-500 shadow-md ring-2 ring-rose-200'
                          : 'bg-white text-rose-950 border-rose-200 hover:border-rose-300 hover:bg-rose-50'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full mb-1">
                        <span className="font-bold text-sm">{mall.name}</span>
                        {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                      </div>
                      <p className={`text-xs ${isSelected ? 'text-rose-100' : 'text-rose-700/80'}`}>
                        {mall.highlight}
                      </p>
                      {mall.isCustom && isSelected && (
                        <div className="mt-3 w-full" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="text"
                            value={customMall}
                            onChange={(e) => setCustomMall(e.target.value)}
                            placeholder="Type any mall you want..."
                            className="w-full px-3 py-1.5 text-xs bg-white text-rose-950 border border-rose-200 rounded-lg focus:outline-none focus:border-rose-400"
                          />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: STAYCATION CHOICES */}
          {activeTab === 'staycation' && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-rose-800">
                  Select a cozy staycation area:
                </span>
                <span className="text-[11px] text-rose-500 font-medium">
                  Selected: {staycationChoice === 'Other Staycation Spot' ? (customStaycation || 'Custom Area') : staycationChoice}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {STAYCATION_OPTIONS.map((stay) => {
                  const isSelected = staycationChoice === stay.name;
                  return (
                    <button
                      key={stay.id}
                      type="button"
                      onClick={() => {
                        setStaycationChoice(stay.name);
                        if (!selectedActivities.includes('Staycation')) {
                          setSelectedActivities((prev) => [...prev, 'Staycation']);
                        }
                      }}
                      className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-rose-500 text-white border-rose-500 shadow-md ring-2 ring-rose-200'
                          : 'bg-white text-rose-950 border-rose-200 hover:border-rose-300 hover:bg-rose-50'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full mb-1">
                        <span className="font-bold text-sm">{stay.name}</span>
                        {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                      </div>
                      <p className={`text-xs ${isSelected ? 'text-rose-100' : 'text-rose-700/80'}`}>
                        {stay.highlight}
                      </p>
                      {stay.isCustom && isSelected && (
                        <div className="mt-3 w-full" onClick={(e) => e.stopPropagation()}>
                          <input
                            type="text"
                            value={customStaycation}
                            onChange={(e) => setCustomStaycation(e.target.value)}
                            placeholder="Type specific staycation place / Airbnb..."
                            className="w-full px-3 py-1.5 text-xs bg-white text-rose-950 border border-rose-200 rounded-lg focus:outline-none focus:border-rose-400"
                          />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: CUSTOM PLANS (OR ALWAYS PRESENT DETAILS) */}
          {activeTab === 'custom' && (
            <div className="p-1">
              <p className="text-xs text-rose-700 leading-relaxed mb-1">
                Customize any dream activity or surprise below! Fill in the detailed plan section.
              </p>
            </div>
          )}
        </div>

        {/* SECTION 3: DETAILED SUGGESTION FIELDS (MANDATORY REQUIREMENT) */}
        <div className="bg-rose-50/70 rounded-2xl p-5 border border-rose-200/80 space-y-4">
          <div className="flex items-center gap-2 text-rose-900 font-bold text-sm sm:text-base">
            <UtensilsCrossed className="w-4 h-4 text-rose-500" />
            <span>Please indicate your plans here:</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Where: */}
            <div>
              <label className="block text-xs font-semibold text-rose-800 mb-1 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-rose-500" />
                Where:
              </label>
              <input
                type="text"
                value={planWhere}
                onChange={(e) => setPlanWhere(e.target.value)}
                placeholder="e.g. Akapela Cafe, SM North, Tagaytay Airbnb..."
                className="w-full px-3.5 py-2.5 bg-white border border-rose-200 rounded-xl text-xs sm:text-sm text-rose-950 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500"
              />
            </div>

            {/* What you expect: */}
            <div>
              <label className="block text-xs font-semibold text-rose-800 mb-1 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-rose-500" />
                What you expect:
              </label>
              <input
                type="text"
                value={planExpectation}
                onChange={(e) => setPlanExpectation(e.target.value)}
                placeholder="e.g. Relaxed chats, warm hugs, taking photos..."
                className="w-full px-3.5 py-2.5 bg-white border border-rose-200 rounded-xl text-xs sm:text-sm text-rose-950 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500"
              />
            </div>

            {/* What to eat: */}
            <div>
              <label className="block text-xs font-semibold text-rose-800 mb-1 flex items-center gap-1.5">
                <UtensilsCrossed className="w-3.5 h-3.5 text-rose-500" />
                What to eat:
              </label>
              <input
                type="text"
                value={planWhatToEat}
                onChange={(e) => setPlanWhatToEat(e.target.value)}
                placeholder="e.g. Pasta, pastries, ramen, iced latte, donuts..."
                className="w-full px-3.5 py-2.5 bg-white border border-rose-200 rounded-xl text-xs sm:text-sm text-rose-950 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500"
              />
            </div>

            {/* Any activities in my mind you want? */}
            <div>
              <label className="block text-xs font-semibold text-rose-800 mb-1 flex items-center gap-1.5">
                <Smile className="w-3.5 h-3.5 text-rose-500" />
                Any activities in my mind you want?
              </label>
              <input
                type="text"
                value={planActivities}
                onChange={(e) => setPlanActivities(e.target.value)}
                placeholder="e.g. Photobooth, watching movies, listening to music..."
                className="w-full px-3.5 py-2.5 bg-white border border-rose-200 rounded-xl text-xs sm:text-sm text-rose-950 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500"
              />
            </div>
          </div>
        </div>

        {/* SECTION 4: SWEET PERSONAL NOTE (OPTIONAL) */}
        <div>
          <label className="block text-xs font-semibold text-rose-800 mb-1.5 flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
            Any message or sweet wish before your flight? (Optional)
          </label>
          <textarea
            rows={2}
            value={personalNote}
            onChange={(e) => setPersonalNote(e.target.value)}
            placeholder="Write a sweet little message here..."
            className="w-full px-3.5 py-2.5 bg-white border border-rose-200 rounded-xl text-xs sm:text-sm text-rose-950 focus:outline-none focus:border-rose-500 focus:ring-1 focus:ring-rose-500 resize-none"
          />
        </div>

        {/* RECIPIENT EMAIL CALLOUT */}
        <div className="bg-rose-100/60 rounded-xl p-3 text-xs text-rose-800 flex items-center justify-between">
          <span>Response will be automatically delivered to:</span>
          <span className="font-mono font-semibold text-rose-900 bg-white px-2 py-0.5 rounded border border-rose-200">
            {RECIPIENT_EMAIL}
          </span>
        </div>

        {/* SUBMIT BUTTON */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 px-6 bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white rounded-full font-bold shadow-xl shadow-rose-400/40 hover:shadow-rose-400/60 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer text-base"
          >
            {isSubmitting ? (
              <span>Locking in our date & sending... 💖</span>
            ) : (
              <>
                <Send className="w-5 h-5 fill-white" />
                <span>Confirm Date & Send Response ♥</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
