import { useEffect, useState } from 'react';

interface Particle {
  id: number;
  left: number;
  size: number;
  duration: number;
  delay: number;
  symbol: string;
}

export function FloatingHearts() {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    const symbols = ['♥', '💖', '✨', '🌸', '💕', '💌', '🤍'];
    const generated: Particle[] = Array.from({ length: 22 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      size: Math.floor(Math.random() * 14) + 14,
      duration: Math.floor(Math.random() * 8) + 9,
      delay: Math.random() * 7,
      symbol: symbols[Math.floor(Math.random() * symbols.length)],
    }));
    setParticles(generated);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map((p) => (
        <span
          key={p.id}
          className="absolute text-pink-300/40 select-none animate-float-heart"
          style={{
            left: `${p.left}%`,
            bottom: '-40px',
            fontSize: `${p.size}px`,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
          }}
          aria-hidden="true"
        >
          {p.symbol}
        </span>
      ))}
    </div>
  );
}
