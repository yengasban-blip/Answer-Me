import React from 'react';
import { Heart, Plane, Sparkles, Frown } from 'lucide-react';

interface LandingViewProps {
  onSayYes: () => void;
  onSayNo: () => void;
}

export function LandingView({ onSayYes, onSayNo }: LandingViewProps) {
  return (
    <div className="relative z-10 w-full max-w-lg mx-auto bg-white/95 backdrop-blur-md rounded-3xl shadow-2xl shadow-rose-200/50 border border-rose-100 p-8 sm:p-10 text-center transition-all duration-300">
      {/* Decorative Top Floating Plane & Heart Motif */}
      <div className="flex items-center justify-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-rose-50 flex items-center justify-center text-rose-500 shadow-inner">
          <Plane className="w-5 h-5 -rotate-45" />
        </div>
        <div className="h-0.5 w-12 border-t-2 border-dashed border-rose-300" />
        <div className="w-12 h-12 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-500 animate-pulse">
          <Heart className="w-6 h-6 fill-rose-500" />
        </div>
      </div>

      {/* Script Accents */}
      <div className="font-script text-5xl sm:text-6xl text-rose-500 mb-1 select-none leading-none">
        Dear my favorite person
      </div>

      <p className="text-xs uppercase tracking-widest text-rose-400 font-semibold mb-6 flex items-center justify-center gap-1.5">
        <Sparkles className="w-3.5 h-3.5" />
        A Special Pre-Flight Invitation
        <Sparkles className="w-3.5 h-3.5" />
      </p>

      {/* Main Proposal Question from user brief */}
      <div className="bg-rose-50/70 rounded-2xl p-6 mb-8 border border-rose-100/80">
        <h1 className="text-xl sm:text-2xl font-bold text-rose-950 leading-snug">
          Will you go on a date with me this weekdays before your flight?
        </h1>
        <p className="text-sm text-rose-800/80 mt-3 leading-relaxed">
          I would love to make some sweet memories, share laughs, and hold your hand one more time before you take off. ✈️💖
        </p>
      </div>

      {/* Interactive Choice Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
        <button
          onClick={onSayYes}
          className="w-full sm:w-auto flex-1 group relative px-7 py-3.5 bg-rose-500 hover:bg-rose-600 text-white rounded-full font-semibold shadow-lg shadow-rose-400/40 hover:shadow-rose-400/60 active:scale-95 transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer text-base"
        >
          <Heart className="w-5 h-5 fill-white group-hover:scale-125 transition-transform duration-200" />
          <span>Of course, yes! ♥</span>
        </button>

        <button
          onClick={onSayNo}
          className="w-full sm:w-auto px-6 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-800 rounded-full font-medium transition-all duration-200 active:scale-95 flex items-center justify-center gap-2 cursor-pointer text-sm"
        >
          <Frown className="w-4 h-4 text-slate-400" />
          <span>No, for now</span>
        </button>
      </div>

      {/* Small Sweet Footer */}
      <div className="mt-8 pt-4 border-t border-rose-100 text-xs text-rose-400 flex items-center justify-center gap-2">
        <span>Sent with warmth & anticipation</span>
        <span>·</span>
        <span className="font-script text-base text-rose-500">Love always</span>
      </div>
    </div>
  );
}
