import starbucksImg from '../assets/images/cafe_starbucks_1791798812189.jpg';
import trinasImg from '../assets/images/cafe_trinas_1791798823256.jpg';
import seattlesBestImg from '../assets/images/cafe_seattles_best_1791798834098.jpg';
import jcoImg from '../assets/images/cafe_jco_1791798845168.jpg';
import krispyKremeImg from '../assets/images/cafe_krispy_kreme_1791798857820.jpg';
import akapelaImg from '../assets/images/cafe_akapela_1791798870382.jpg';

export interface CafeOption {
  id: string;
  name: string;
  description: string;
  image: string;
  isSpecial?: boolean;
  specialBadge?: string;
  isCustom?: boolean;
}

export const CAFE_OPTIONS: CafeOption[] = [
  {
    id: 'akapela',
    name: 'Akapela Cafe',
    description: 'Where we did our first cafe date! Acoustic warmth, fairy lights & memories.',
    image: akapelaImg,
    isSpecial: true,
    specialBadge: 'Our 1st Cafe Date ♥',
  },
  {
    id: 'starbucks',
    name: 'Starbucks',
    description: 'Cozy corners, your favorite handcrafted coffee, and warm pastries.',
    image: starbucksImg,
  },
  {
    id: 'trinas',
    name: "Trina's",
    description: 'Charming boutique cafe with artisanal sweet treats, strawberry cakes & latte art.',
    image: trinasImg,
  },
  {
    id: 'seattles_best',
    name: "Seattle's Best",
    description: 'Smooth rich roasts, warm cinnamon pastries, and relaxed cafe ambiance.',
    image: seattlesBestImg,
  },
  {
    id: 'jco',
    name: 'J.CO Donuts & Coffee',
    description: 'Irresistible Alcapone glazed donuts with chilled Jcoccino blends.',
    image: jcoImg,
  },
  {
    id: 'krispy_kreme',
    name: 'Krispy Kreme',
    description: 'Fresh warm original glazed doughnuts straight off the line with hot coffee.',
    image: krispyKremeImg,
  },
  {
    id: 'custom_cafe',
    name: 'Any on your mind?',
    description: 'Suggest your favorite hidden gem cafe you have been wanting to visit!',
    image: '',
    isCustom: true,
  },
];

export interface MallOption {
  id: string;
  name: string;
  highlight: string;
  isCustom?: boolean;
}

export const MALL_OPTIONS: MallOption[] = [
  {
    id: 'sm_marilao',
    name: 'SM Marilao',
    highlight: 'Accessible, cozy dining spots & familiar comfort strolls',
  },
  {
    id: 'sm_north',
    name: 'SM North EDSA',
    highlight: 'Sky Garden breeze, endless food options & cinema',
  },
  {
    id: 'trinoma',
    name: 'Trinoma',
    highlight: 'Rooftop gardens, quiet cafes & romantic walkways',
  },
  {
    id: 'moa',
    name: 'SM Mall of Asia (MOA)',
    highlight: 'Sunset by the bay, seaside breeze & giant Ferris wheel',
  },
  {
    id: 'custom_mall',
    name: 'Any mall you desire to go',
    highlight: 'Tell me which mall you are craving to visit!',
    isCustom: true,
  },
];

export interface StaycationOption {
  id: string;
  name: string;
  area: string;
  highlight: string;
  isCustom?: boolean;
}

export const STAYCATION_OPTIONS: StaycationOption[] = [
  {
    id: 'bulacan',
    name: 'Bulacan Area',
    area: 'Bulacan',
    highlight: 'Peaceful nearby getaway, relaxing nature & serene private suites',
  },
  {
    id: 'morato',
    name: 'Morato Area',
    area: 'Tomas Morato, QC',
    highlight: 'Trendy food street, aesthetic lofts & intimate night vibes',
  },
  {
    id: 'tagaytay',
    name: 'Tagaytay Area',
    area: 'Tagaytay',
    highlight: 'Cool crisp mountain breeze, cozy bulalo & scenic lake views',
  },
  {
    id: 'cubao',
    name: 'Cubao Area',
    area: 'Cubao / Expo',
    highlight: 'Artistic retro lofts, vinyl cafes & vibrant cozy spaces',
  },
  {
    id: 'bgc',
    name: 'BGC Area',
    area: 'Bonifacio Global City',
    highlight: 'High-rise skyline views, lush parks & world-class dining',
  },
  {
    id: 'custom_staycation',
    name: 'Other Staycation Spot',
    area: 'Custom',
    highlight: 'Have an Airbnb or hotel in mind? Let me know!',
    isCustom: true,
  },
];

export const TIME_OF_DAY_OPTIONS = [
  { id: 'morning', label: 'Morning Coffee & Breakfast', time: '9:00 AM – 12:00 PM', icon: '☀️' },
  { id: 'afternoon', label: 'Afternoon Chill & Snacks', time: '1:00 PM – 4:30 PM', icon: '☕' },
  { id: 'sunset', label: 'Golden Hour & Dinner', time: '5:00 PM – 8:00 PM', icon: '🌅' },
  { id: 'evening', label: 'Cozy Evening Hangout', time: '7:30 PM onwards', icon: '🌙' },
];

export const SAD_REASON_SUGGESTIONS = [
  'Need to pack my bags and organize luggage 🧳',
  'Super exhausted and need rest before the flight 😴',
  'Strict flight preparations & errands ✈️',
  'Family time and commitments before departure 👨‍👩‍👧',
  'Feeling unwell / need to recharge 🤒',
  'Timing is too tight this week ⏳',
];

export const RECIPIENT_EMAIL = 'ellerellama02@gmail.com';
