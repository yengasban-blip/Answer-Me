/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { FloatingHearts } from './components/FloatingHearts';
import { LandingView } from './components/LandingView';
import { YesPlanningView } from './components/YesPlanningView';
import { SadView } from './components/SadView';
import { SuccessView } from './components/SuccessView';
import { DatePlanPayload } from './services/emailService';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'landing' | 'planning' | 'sad' | 'success'>('landing');
  const [completedPlan, setCompletedPlan] = useState<DatePlanPayload | null>(null);

  const handleSayYes = () => {
    setCurrentPage('planning');
  };

  const handleSayNo = () => {
    setCurrentPage('sad');
  };

  const handlePlanSuccess = (data: DatePlanPayload) => {
    setCompletedPlan(data);
    setCurrentPage('success');
  };

  const handleBackToLanding = () => {
    setCurrentPage('landing');
  };

  const handleChangedMind = () => {
    setCurrentPage('planning');
  };

  const handleEditPlan = () => {
    setCurrentPage('planning');
  };

  const isSadView = currentPage === 'sad';

  return (
    <main
      className={`min-h-screen relative flex items-center justify-center p-4 sm:p-6 transition-colors duration-700 overflow-x-hidden ${
        isSadView
          ? 'bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100'
          : 'bg-gradient-to-br from-rose-50 via-pink-50 to-rose-100 text-rose-950'
      }`}
    >
      {/* Floating romantic hearts on all non-sad pages */}
      {!isSadView && <FloatingHearts />}

      {/* Dynamic Views */}
      {currentPage === 'landing' && (
        <LandingView onSayYes={handleSayYes} onSayNo={handleSayNo} />
      )}

      {currentPage === 'planning' && (
        <YesPlanningView
          onBack={handleBackToLanding}
          onSuccess={handlePlanSuccess}
        />
      )}

      {currentPage === 'sad' && (
        <SadView
          onBack={handleBackToLanding}
          onChangedMind={handleChangedMind}
        />
      )}

      {currentPage === 'success' && completedPlan && (
        <SuccessView
          data={completedPlan}
          onEdit={handleEditPlan}
          onReset={handleBackToLanding}
        />
      )}
    </main>
  );
}
